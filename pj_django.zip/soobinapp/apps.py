from django.apps import AppConfig


class SoobinappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'soobinapp'
