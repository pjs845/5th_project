from django.apps import AppConfig


class CampappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'campapp'
